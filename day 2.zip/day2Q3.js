// console.log("Hello")
//Alert:these makes not to interact with your webpages

//alert("wait do you wanna go into it");
// prompt:syntax=prompt("title",default value)
//let age=prompt("whats you work","student");
//console.log(age);

// confirm returns true or false in console
age=confirm("Are u 21+");
if(age==true){
    console.log("you can drink");
}
else{
console.log("you cannot drink")
}
