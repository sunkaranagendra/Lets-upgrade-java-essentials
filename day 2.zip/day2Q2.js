 name="nag"
 skill="hackar"
 weaknes="turkey is large city"
 console.log(" the name is"+name+"my skill is"+skill);
 console.log(`the name is ${name}.his skill is ${skill}.`);
console.log(skill.length)
console.log(skill.toLowerCase())
console.log(name.toUpperCase())
console.log(skill[3])
console.log(skill.indexOf('a'))
console.log(skill.lastIndexOf('a'))
console.log(skill.charAt('4'))
console.log(skill.endsWith("r"))
console.log(weaknes.split(' '))
// console.log(weakness.sustring("is"))
//substring splice replace all replace 
console.log(weaknes.substring(5,6))
console.log(weaknes.replace("is","was"))
// console.log(weaknes.replaceAll("e","a"))
console.log(weaknes.includes("is"))

h="     hello hii   "
console.log(h)
console.log(h.trim()) // trim extra spaces 
let arr=['one',2,'two']
console.log(arr)
console.log(Array.isArray(arr))
console.log(arr.reverse())
console.log(arr)
//array work with addresss ,so original also changes on own 
console.log(arr.concat([1,5]))
// appending an element at start is 
console.log(arr.unshift('hii'))
console.log(arr)
// remove at start
console.log(arr.shift())
console.log(arr)
//. at the end
console.log(arr.push("hello"))
console.log(arr.pop())
console.log(arr.fill("0"))
console.log(arr.fill(10)) // fill all values with the given value
// console.log(arr.findIndex(10))
console.log(arr.splice(1,1,"kangroo","manfo","turkey")) // insert the values starting from index 1 and remove 1 element from index 1 

console.log(arr)
console.log(arr.slice(1,3))
console.log(arr)