alert(" hello ,you have to enter you name to enter")
name=prompt("enter you name","user")
console.log(name+" you have entered tq");